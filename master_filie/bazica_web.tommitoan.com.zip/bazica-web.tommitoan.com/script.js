const vietnameseTerms = {
    "Yang Wood": "Giáp", "Yin Wood": "Ất", "Yang Fire": "Bính", "Yin Fire": "Đinh",
    "Yang Earth": "Mậu", "Yin Earth": "Kỷ", "Yang Metal": "Canh", "Yin Metal": "Tân",
    "Yang Water": "Nhâm", "Yin Water": "Quý", "Rat": "Tý", "Ox": "Sửu", "Tiger": "Dần",
    "Rabbit": "Mão", "Dragon": "Thìn", "Snake": "Tỵ", "Horse": "Ngọ", "Goat": "Mùi",
    "Monkey": "Thân", "Rooster": "Dậu", "Dog": "Tuất", "Pig": "Hợi",

    // GanZhi Translations
    "Sea metal": "Hải Trung Kim",
    "Furnace fire": "Lò Trung Hỏa",
    "Forest wood": "Đại Lâm Mộc",
    "Road earth": "Lộ Bàng Thổ",
    "Sword metal": "Kiếm Phong Kim",
    "Volcanic fire": "Sơn Đầu Hỏa",
    "Cave water": "Giản Hạ Thủy",
    "Fortress earth": "Thành Đầu Thổ",
    "Wax metal": "Bạch Lạp Kim",
    "Willow wood": "Dương Liễu Mộc",
    "Stream water": "Tuyền Trung Thủy",
    "Roof tiles earth": "Ốc Thượng Thổ",
    "Lightning fire": "Tích Lịch Hỏa",
    "Conifer wood": "Tùng Bách Mộc",
    "River water": "Trường Lưu Thủy",
    "Sand metal": "Sa Trung Kim",
    "Forest fire": "Sơn Hạ Hỏa",
    "Meadow wood": "Bình Địa Mộc",
    "Adobe earth": "Bích Thượng Thổ",
    "Precious metal": "Kim Bạch Kim",
    "Lamp fire": "Phúc Đăng Hỏa",
    "Sky water": "Thiên Hà Thủy",
    "Highway earth": "Đại Trạch Thổ",
    "Jewellery metal": "Thoa Xuyến Kim",
    "Mulberry wood": "Tang Đố Mộc",
    "Rapids water": "Đại Khê Thủy",
    "Desert earth": "Sa Trung Thổ",
    "Sun fire": "Thiên Thượng Hỏa",
    "Pomegranate wood": "Thạch Lựu Mộc",
    "Ocean water": "Đại Hải Thủy",

    // LifeCycle Translations
    "Birth": "Sinh",
    "Bath": "Mộc Dục",
    "Youth": "Quan Đới",
    "Thriving": "Lâm Quan",
    "Prosperous": "Đế Vượng",
    "Weakening": "Suy",
    "Sick": "Bệnh",
    "Death": "Tử",
    "Grave": "Mộ",
    "Extinction": "Tuyệt",
    "Conceived": "Thai",
    "Nourishing": "Dưỡng",

};

const languageStrings = {
    English: {
        pageTitle: "Bazi Calculator",
        mainHeading: "🪬 Bazi Calculator 🪬",
        dateTimeLabel: "Date and Time:",
        locationLabel: "Timezone:",
        fourPillarsHeading: "Four Pillars:",
        luckPillarsHeading: "Luck Pillars:",
        YearPillar: "Year Pillar",
        MonthPillar: "Month Pillar",
        DayPillar: "Day Pillar",
        HourPillar: "Hour Pillar",
        calculateButton: "Calculate",
        genderLabel: "Gender:",
        femaleLabel: "Female",
        maleLabel: "Male",
        noTimezoneSelected: "Please select a timezone.",
        noGenderSelected: "Please select a gender.",
        noDateTimeSelected: "Please select a date and time.",
    },
    Vietnamese: {
        pageTitle: "Lập lá số Bát Tự",
        mainHeading: "🪬 Lập lá số Bát Tự 🪬",
        dateTimeLabel: "Giờ sinh (Dương Lịch):",
        locationLabel: "Múi giờ:",
        fourPillarsHeading: "Bát tự:",
        luckPillarsHeading: "Đại vận:",
        YearPillar: "Niên Trụ",
        MonthPillar: "Nguyệt Trụ",
        DayPillar: "Nhật Trụ",
        HourPillar: "Thời Trụ",
        calculateButton: "Lập lá số",
        genderLabel: "Giới tính:",
        femaleLabel: "Nữ",
        maleLabel: "Nam",
        noTimezoneSelected: "Vui lòng chọn múi giờ.",
        noGenderSelected: "Vui lòng chọn giới tính.",
        noDateTimeSelected: "Vui lòng chọn ngày và giờ sinh.",
    }
};

const elementColors = {
    "Fire": "#f44336",    // A more vibrant red
    "Wood": "#4CAF50",    // A darker, richer green
    "Earth": "#bc8a60",   // A warmer brown with a hint of orange
    "Water": "#2196F3",    // A classic, slightly deeper blue
    "Metal": "#96a6ae",    // A darker, more legible gray
};

const branchAssociations = {
    "Tiger": "Wood", "Dần": "Wood",
    "Rabbit": "Wood", "Mão": "Wood",
    "Snake": "Fire", "Tỵ": "Fire",
    "Horse": "Fire", "Ngọ": "Fire",
    "Monkey": "Metal", "Thân": "Metal",
    "Rooster": "Metal", "Dậu": "Metal",
    "Pig": "Water", "Hợi": "Water",
    "Rat": "Water", "Tý": "Water",
    "Dragon": "Earth", "Thìn": "Earth",
    "Goat": "Earth", "Mùi": "Earth",
    "Dog": "Earth", "Tuất": "Earth",
    "Ox": "Earth", "Sửu": "Earth"
};

let isEnglish = true;
let currentLanguage = 'English';

function calculateBazi() {
    const dateTimeInput = document.getElementById("dateTime");
    const locationInput = document.getElementById("location");
    const resultDiv = document.getElementById("result");
    const luckPillarsDiv = document.getElementById("luckPillars");
    const errorDiv = document.getElementById("error");

    // Get selected gender
    const genderRadios = document.getElementsByName("gender");
    let selectedGender = null; // Initialize as null
    for (const radio of genderRadios) {
        if (radio.checked) {
            selectedGender = parseInt(radio.value, 10);
            break;
        }
    }

    // Clear previous error message
    errorDiv.style.display = 'none';

    // Check if date and time is selected
    if (!dateTimeInput.value) {
        errorDiv.textContent = languageStrings[currentLanguage].noDateTimeSelected;
        errorDiv.style.display = 'block';
        return;
    }

    // Date and Time Validation
    const dateTimeValue = dateTimeInput.value;
    if (!dateTimeValue) {
        errorDiv.textContent = languageStrings[currentLanguage].noDateTimeSelected;
        errorDiv.style.display = 'block';
        return;
    }

    const inputDate = new Date(dateTimeValue);
    const startYear = 1900;
    const endYear = 2100;

    if (inputDate.getFullYear() < startYear || inputDate.getFullYear() > endYear) {
        errorDiv.textContent = isEnglish
            ? `Year must be between ${startYear} and ${endYear}`
            : `Năm sinh phải từ ${startYear} đến ${endYear}`;
        errorDiv.style.display = 'block';
        return;
    }

    // Check if timezone is selected
    if (!locationInput.value) {
        errorDiv.textContent = languageStrings[currentLanguage].noTimezoneSelected;
        errorDiv.style.display = 'block';
        return;
    }

    // Check if gender is selected
    if (selectedGender === null) {
        errorDiv.textContent = languageStrings[currentLanguage].noGenderSelected;
        errorDiv.style.display = 'block';
        return;
    }

    resultDiv.style.display = "none";
    luckPillarsDiv.style.display = "none";
    errorDiv.style.display = "none";

    // Create a new object before sending the data.
    const requestData = {
        dateTime: dateTimeInput.value,
        location: locationInput.value,
        gender: selectedGender,
    };

    fetch('/calculate', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(requestData), // Send the requestData object
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok.');
            }
            return response.json();
        })
        .then(data => {
            displayPillar(data.four_pillars.year_pillar, "YearPillar");
            displayPillar(data.four_pillars.month_pillar, "MonthPillar");
            displayPillar(data.four_pillars.day_pillar, "DayPillar");
            displayPillar(data.four_pillars.hour_pillar, "HourPillar");
            displayLuckPillars(data.luck_pillars);
            resultDiv.style.display = "block";
            document.getElementById("luckPillars").style.display = "flex";
            document.getElementById("resultsContainer").style.display = "block"; // Show the container
        })
        .catch(error => {
            errorDiv.textContent = "Error: " + error.message;
            errorDiv.style.display = "block";
        });

    // GSAP animation on successful calculation
    gsap.from("#result", { duration: 1, opacity: 0, y: 50, stagger: 0.2 });
    gsap.from(".luckPillar", { duration: 1, opacity: 0, y: 50, stagger: 0.2 });
    gsap.from("#resultsContainer", { duration: 1, opacity: 0, y: 50 });
}

function displayPillar(pillarData, element) {
    let div;
    if (typeof element === 'string') {
        div = document.getElementById(element);
    } else {
        div = element;
    }

    let heavenlyStemName = pillarData.heavenly_stem.name;
    let heavenlyStemCharacter = pillarData.heavenly_stem.character;
    let earthlyBranchName = pillarData.earthly_branch.name;
    let earthlyBranchCharacter = pillarData.earthly_branch.character;

    // Get element and branch element before translation
    let heavenlyStemElement = heavenlyStemName.split(" ")[1];
    let earthlyBranchElement = branchAssociations[earthlyBranchName];

    // Extract GanZhi information
    let ganZhiName = ""; // Default to empty string if gan_zhi is undefined
    let ganZhiElement = "";
    if (pillarData.gan_zhi) { // This is for Four Pillars (Bát Tự)
        ganZhiName = pillarData.gan_zhi.name;
        ganZhiElement = pillarData.gan_zhi.element_name || "";
    } else if (pillarData.heavenly_stem && pillarData.heavenly_stem.gan_zhi) { // Check both heavenly_stem and gan_zhi within it
        ganZhiName = pillarData.heavenly_stem.gan_zhi.name;
        ganZhiElement = pillarData.heavenly_stem.gan_zhi.element_name || "";
    }

    if (!ganZhiName) { // Check if GanZhiName is still empty after the checks
        ganZhiName = isEnglish ? "N/A" : "Không có"; // Set to "N/A" or its Vietnamese equivalent
    }

    // Extract LifeCycle information only for Four Pillars
    let lifeCycleName = "";
    if (pillarData.life_cycle) { // Check if it's a Four Pillars data with gan_zhi
        lifeCycleName = pillarData.life_cycle;
    }

    if (!isEnglish) {
        heavenlyStemName = vietnameseTerms[heavenlyStemName];
        earthlyBranchName = vietnameseTerms[earthlyBranchName];
        ganZhiName = vietnameseTerms[ganZhiName]; // Translate GanZhi name
        lifeCycleName = vietnameseTerms[lifeCycleName]; // Translate LifeCycle name
    }

    const luckPillarTitle = isEnglish ? "Luck " : "Đại Vận ";
    const startYearLabel = isEnglish ? "Start: " : "Khởi: ";
    const endYearLabel = isEnglish ? "End: " : "Kết: ";
    const ageLabel = isEnglish ? "Time: " : "Lúc: ";

    let title = languageStrings[currentLanguage][div.id];
    let additionalInfo = '';

    // Modify age calculation
    let formattedAge = "";
    if (pillarData.number !== undefined) {
        title = luckPillarTitle + pillarData.number;
        if (pillarData.time) {
            let ageDate = new Date(pillarData.time);
            // Apply timezone offset
            ageDate.setMinutes(ageDate.getMinutes() - ageDate.getTimezoneOffset());

            // Format without hours/minutes and add timezone
            formattedAge = `${ageDate.toLocaleString('en-US', {month: 'long'})} ${ageDate.getDate()}`;
        }

        additionalInfo = `
        <div>${startYearLabel}${pillarData.year_start}</div>
        <div>${ageLabel}${formattedAge}</div>
        <div>${endYearLabel}${pillarData.year_end}</div>
    `;
    }

    const pillarValue = `
        <div class="pillar-title">${title}</div>
        <hr>
        <div class="pillar-value d-flex flex-column align-items-center">
            <strong id="bigCharacter" style="color: ${elementColors[heavenlyStemElement]}">${heavenlyStemCharacter}</strong>
            <div id="bigValue" style="color: ${elementColors[heavenlyStemElement]}">${heavenlyStemName}</div>
        </div>
        <hr>
        <div class="pillar-value d-flex flex-column align-items-center">
            <strong id="bigCharacter" style="color: ${elementColors[earthlyBranchElement]}">${earthlyBranchCharacter}</strong>
            <div id="bigValue" style="color: ${elementColors[earthlyBranchElement]}">${earthlyBranchName}</div>
        </div>
        <hr>
        <div class="ganzhi-separator">
            <strong style="color: ${elementColors[ganZhiElement]}">${ganZhiName}</strong>
        </div>
        <hr>
        ${lifeCycleName ? `<div class="lifecycle-separator">
            <div id="lifeCycle">${lifeCycleName}</div>
        </div>` : ''}
        <div>${additionalInfo}</div>
    `;

    div.innerHTML = pillarValue;
}

function displayLuckPillars(luckPillarsData) {
    const luckPillarsDiv = document.getElementById("luckPillars");

    // Clear existing Luck Pillars
    while (luckPillarsDiv.firstChild) {
        luckPillarsDiv.removeChild(luckPillarsDiv.firstChild);
    }

    luckPillarsData.luck_pillars.forEach((pillar, index) => {
        const pillarDiv = document.createElement("div");
        pillarDiv.classList.add("pillar");
        pillarDiv.style.width = ""; // Remove inline width
        displayPillar(pillar, pillarDiv);
        luckPillarsDiv.appendChild(pillarDiv);
    });
}

function toggleLanguage(language) {
    isEnglish = (language === 'English');
    currentLanguage = language;

    const englishButton = document.getElementById("englishButton");
    const vietnameseButton = document.getElementById("vietnameseButton");

    englishButton.disabled = isEnglish;
    vietnameseButton.disabled = !isEnglish;

    if (document.getElementById("result").style.display === "block") {
        calculateBazi();
    }

    updateTextElements();
}

// updateTextElements function (remove unnecessary part)
function updateTextElements() {
    // Update all text elements with their corresponding translations
    for (const [id, text] of Object.entries(languageStrings[currentLanguage])) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = text;
        }
    }

    // Update the Calculate button text
    const calculateButton = document.getElementById("calculateButton");
    if (calculateButton) {
        calculateButton.textContent = languageStrings[currentLanguage].calculateButton;
    }

    // Update gender labels
    document.getElementById("femaleRadio").nextElementSibling.textContent = languageStrings[currentLanguage].femaleLabel;
    document.getElementById("maleRadio").nextElementSibling.textContent = languageStrings[currentLanguage].maleLabel;

    const currentYearSpan = document.getElementById("current-year");
    if (currentYearSpan) {
        currentYearSpan.textContent = new Date().getFullYear();
    }

}

// Initial call to set text on page load
updateTextElements(); // Initial call to set text on page load